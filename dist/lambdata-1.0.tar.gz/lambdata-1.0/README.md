# lambdata





## Installation 



```sh
pip install ________
```


## USAGE


```py
from mylambdata.mymod import enlarge


print(enlarge(8))
```



